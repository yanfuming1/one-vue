import meetingManage from './components/meetingManage'

export default meetingManage