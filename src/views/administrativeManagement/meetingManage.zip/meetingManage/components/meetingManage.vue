<template>
  <d2-container type="fulls">
    <template slot="header">
      <div class="qqt-container-full-header___top">

          <span class="qqt-container-full-header-operation___left">
          <el-button type="primary" class="qqt-container-full-header-top___button"  >添加</el-button>
          </span>
        <span class="qqt-container-full-header___search">

          <el-input
              placeholder="请输入内容"
              prefix-icon="el-icon-search"
              size="mini">
          </el-input>
          <el-button type="primary" class="qqt-container-full-header-top___button" >搜索</el-button>
        </span>

        <span class="qqt-container-full-header-operation___right">
          <el-date-picker

              size="mini"

              type="datetimerange"

              value-format="yyyy-MM-dd HH:mm:ss"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              :default-time="['08:00:00', '18:00:00']"

              align="right">
          </el-date-picker>
        </span>


        <span class="qqt-container-full-header-operation___right">
            <p>状态</p>
              <div class="qqt-container-full-header-state___select" style="width:160px;">
                <el-select :size="'mini'" :placeholder="'请选择要搜索的状态'" value=""></el-select>
              </div>
          
           </span>
        <span class="qqt-container-full-header-operation___right">

            <p>办理状态</p>
              <div class="qqt-container-full-header-state___select" style="width:160px;">
                <el-select :size="'mini'" :placeholder="'请选择要搜索的状态'" value=""></el-select>
              </div>

           </span>
        <span class="qqt-container-full-header-operation___right">

            <p>审核状态</p>
              <div class="qqt-container-full-header-state___select" style="width:160px;">
                <el-select :size="'mini'" :placeholder="'请选择要搜索的状态'" value=""></el-select>
              </div>

           </span>
        <span class="qqt-container-full-header-operation___right">
          <div style="height: 10px;"></div>
          &nbsp;
           <el-button type="primary" class="qqt-container-full-header-top___button" >重置</el-button>
           <el-button type="info" class="qqt-container-full-header-top___button" >批量删除</el-button>


        </span>

      </div>
    </template>
  </d2-container>
</template>

<script>
import {qqtTable, qqtSelect} from "../../../../components/qqt-subassembly"
import util from '@/libs/util.js'

export default {
  name: "meetingManage",
  components: {qqtTable, qqtSelect},
}
</script>

<style scoped>

</style>